package com.example.rdfsearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RdfSearchBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
