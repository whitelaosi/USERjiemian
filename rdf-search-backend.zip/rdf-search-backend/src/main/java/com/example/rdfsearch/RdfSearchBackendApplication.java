package com.example.rdfsearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RdfSearchBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(RdfSearchBackendApplication.class, args);
	}

}
